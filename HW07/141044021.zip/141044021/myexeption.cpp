/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   myexeption.cpp
 * Author:  Emre Behadir 141044021
 * 
 * Created on 25 Aralık 2016 Pazar, 11:44
 */

#include "myexeption.h"

myexeption::myexeption() {
}


