/* 
 * File:   instruction.cpp
 * Author: Emre Behadir 141044021
 * 
 * Created on 23 Ekim 2016 Pazar, 11:10
 */

#include "instruction.h"

instruction::instruction() {
    opCode="";
    operandOne="";
    operandTwo="";
    op1=0;
    op2=0;
}



