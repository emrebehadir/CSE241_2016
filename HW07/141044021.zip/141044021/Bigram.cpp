/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Bigram.cpp
 * Author: testbhdr
 * 
 * Created on 22 Aralık 2016 Perşembe, 20:55
 */

#include "Bigram.h"
