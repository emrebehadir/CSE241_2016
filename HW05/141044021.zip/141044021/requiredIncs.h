/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   requiredIncs.h
 * Author: testbhdr
 *
 * Created on 04 Kasım 2016 Cuma, 13:17
 */

#ifndef REQUIREDINCS_H
#define REQUIREDINCS_H

#include "Computer.h"




#endif /* REQUIREDINCS_H */

